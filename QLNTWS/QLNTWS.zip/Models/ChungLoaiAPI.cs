﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QLNTWS.Models
{
    public class ChungLoaiAPI
    {
    }
}