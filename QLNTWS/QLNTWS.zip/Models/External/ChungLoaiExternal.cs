﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace QLNTWS.Models
{
    public partial class ChungLoai
    {
        public string DuongDanHinh
        {
            get {
                return "";
            }
        }
    }
}