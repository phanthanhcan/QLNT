﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QLNTWS.Models
{
    public partial class Loai
    {
        public string DuongDanHinh
        {
            get
            {
                return "";
            }
        }
    }
}